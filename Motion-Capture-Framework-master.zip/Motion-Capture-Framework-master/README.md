# Motion-Capture-Framework
This is a motion capture framework designed using X-Box Kinect. It can track various human exercises and provide live analysis of how close a user is performing the excercise when compared to an expert.

## Preface
This project was created as a part of our 6th Semester project which was of 5 cerdits.

## Technologies used
* C++
* X-Box Kinect
* Visual Studio

## Authors
* Suras Kumar Nayak
* Kamal Nayan Chaubey
* Mohammad Aquib
* Anant Chaturvedi
* Saurabh Kumar
